package com.example.extrabows;

import net.minecraft.core.registries.Registries;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

@Mod(ExtraBows.MODID)
public class ExtraBows {
    public static final String MODID = "extrabows";

    /** Multi bow: reset i-frames on hit so every arrow of the volley deals full damage. */
    public static final boolean MULTI_RESETS_IFRAMES = true;

    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(MODID);

    // (drawTicks, velocityMult, volley, volleyDelayTicks, flatDamage(power))
    // Vanilla bow: drawTicks = 20, velocityMult = 1.0
    public static final DeferredItem<CustomBowItem> LONG_BOW = ITEMS.register("long_bow",
            () -> new CustomBowItem(new Item.Properties().durability(384),
                    32, 1.5F, 1, 0, power -> power >= 1.0F ? 3.0F : 0.0F));

    public static final DeferredItem<CustomBowItem> RAPID_BOW = ITEMS.register("rapid_bow",
            () -> new CustomBowItem(new Item.Properties().durability(384),
                    12, 0.4F, 1, 0, power -> -2.0F * power));

    public static final DeferredItem<CustomBowItem> MULTI_BOW = ITEMS.register("multi_bow",
            () -> new CustomBowItem(new Item.Properties().durability(384),
                    24, 0.6F, 3, 4, power -> 0.0F));

    public ExtraBows(IEventBus modBus) {
        ITEMS.register(modBus);
        modBus.addListener(ExtraBows::addToCreativeTab);
    }

    private static void addToCreativeTab(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.COMBAT) {
            event.accept(LONG_BOW);
            event.accept(RAPID_BOW);
            event.accept(MULTI_BOW);
        }
    }
}
