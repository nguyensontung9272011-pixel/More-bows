package com.example.extrabows;

import java.util.List;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.stats.Stats;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.item.BowItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.neoforged.neoforge.event.EventHooks;
import org.jetbrains.annotations.Nullable;

public class CustomBowItem extends BowItem {
    public static final int USE_DURATION = 72000; // same value as vanilla BowItem
    public static final String MULTI_TAG = "extrabows_multi";

    @FunctionalInterface
    public interface FlatDamage {
        /** @param power 0..1 (1 = full draw) @return damage added to the vanilla-equivalent damage */
        float get(float power);
    }

    private final int drawTicks;
    private final float velocityMult;
    private final int volley;
    private final int volleyDelay;
    private final FlatDamage flatDamage;
    private boolean extraShot = false; // true while firing the 2nd/3rd arrow of a volley

    public CustomBowItem(Properties props, int drawTicks, float velocityMult, int volley,
                         int volleyDelay, FlatDamage flatDamage) {
        super(props);
        this.drawTicks = drawTicks;
        this.velocityMult = velocityMult;
        this.volley = volley;
        this.volleyDelay = volleyDelay;
        this.flatDamage = flatDamage;
    }

    public int getDrawTicks() {
        return drawTicks;
    }

    private float powerFor(int charge) {
        float f = (float) charge / drawTicks;
        f = (f * f + f * 2.0F) / 3.0F; // same curve as vanilla, just stretched over drawTicks
        return Math.min(f, 1.0F);
    }

    @Override
    public int getDefaultProjectileRange() {
        return Math.max(1, Math.round(15 * velocityMult));
    }

    @Override
    public void releaseUsing(ItemStack stack, Level level, LivingEntity entity, int timeLeft) {
        if (!(entity instanceof Player player)) return;
        ItemStack ammo = player.getProjectile(stack);
        if (ammo.isEmpty()) return;

        int charge = USE_DURATION - timeLeft;
        charge = EventHooks.onArrowLoose(stack, level, player, charge, true);
        if (charge < 0) return;

        float power = powerFor(charge);
        if (power < 0.1F) return;

        // Snapshot BEFORE shooting (the bow may break on the first shot)
        ItemStack weaponSnapshot = stack.copy();
        if (weaponSnapshot.isDamageableItem()) weaponSnapshot.setDamageValue(0);

        List<ItemStack> projectiles = draw(stack, ammo, player);
        if (level instanceof ServerLevel server && !projectiles.isEmpty()) {
            float velocity = power * 3.0F * velocityMult;
            boolean crit = power >= 1.0F;
            InteractionHand hand = player.getUsedItemHand();
            ItemStack extraAmmo = projectiles.get(0).copy();

            this.shoot(server, player, hand, stack, projectiles, velocity, 1.0F, crit, null);

            for (int i = 1; i < volley; i++) {
                BowEvents.schedule(volleyDelay * i,
                        () -> shootExtra(server, player, hand, weaponSnapshot, extraAmmo, velocity, crit));
            }
        }

        level.playSound(null, player.getX(), player.getY(), player.getZ(),
                SoundEvents.ARROW_SHOOT, SoundSource.PLAYERS, 1.0F,
                1.0F / (level.getRandom().nextFloat() * 0.4F + 1.2F) + power * 0.5F);
        player.awardStat(Stats.ITEM_USED.get(this));
    }

    private void shootExtra(ServerLevel level, Player player, InteractionHand hand,
                            ItemStack weaponSnapshot, ItemStack ammo, float velocity, boolean crit) {
        if (!player.isAlive() || player.level() != level || weaponSnapshot.isEmpty()) return;
        extraShot = true;
        try {
            // copy of the bow so extra arrows don't cost extra durability
            this.shoot(level, player, hand, weaponSnapshot.copy(), List.of(ammo.copy()),
                    velocity, 1.0F, crit, null);
        } finally {
            extraShot = false;
        }
        level.playSound(null, player.getX(), player.getY(), player.getZ(),
                SoundEvents.ARROW_SHOOT, SoundSource.PLAYERS, 1.0F,
                1.0F / (level.getRandom().nextFloat() * 0.4F + 1.2F) + 0.5F);
    }

    @Override
    protected void shootProjectile(LivingEntity shooter, Projectile projectile, int index,
                                   float velocity, float inaccuracy, float angle,
                                   @Nullable LivingEntity target) {
        super.shootProjectile(shooter, projectile, index, velocity, inaccuracy, angle, target);

        if (projectile instanceof AbstractArrow arrow && velocity > 0.0F) {
            float power = Mth.clamp(velocity / (3.0F * velocityMult), 0.0F, 1.0F);

            // Damage a vanilla bow would deal at this draw (includes Power enchant)
            double vanillaDamage = arrow.getBaseDamage() * (velocity / velocityMult);
            double wanted = Math.max(1.0D, vanillaDamage + flatDamage.get(power));
            // Arrow damage = speed * baseDamage, so divide by the (scaled) speed
            arrow.setBaseDamage(wanted / velocity);

            if (volley > 1) arrow.addTag(MULTI_TAG);
            if (extraShot) arrow.pickup = AbstractArrow.Pickup.DISALLOWED;
        }
    }
}
