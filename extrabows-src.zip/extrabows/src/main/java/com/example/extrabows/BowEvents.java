package com.example.extrabows;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.phys.EntityHitResult;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.ProjectileImpactEvent;
import net.neoforged.neoforge.event.server.ServerStoppedEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

@EventBusSubscriber(modid = ExtraBows.MODID)
public final class BowEvents {
    private static final class Task {
        int ticks;
        final Runnable action;
        Task(int ticks, Runnable action) {
            this.ticks = ticks;
            this.action = action;
        }
    }

    private static final List<Task> TASKS = new ArrayList<>();

    /** Run an action after delayTicks server ticks (20 ticks = 1s, so 0.2s = 4 ticks). */
    public static void schedule(int delayTicks, Runnable action) {
        TASKS.add(new Task(delayTicks, action));
    }

    @SubscribeEvent
    public static void onServerTick(ServerTickEvent.Post event) {
        if (TASKS.isEmpty()) return;
        List<Task> due = new ArrayList<>();
        Iterator<Task> it = TASKS.iterator();
        while (it.hasNext()) {
            Task t = it.next();
            if (--t.ticks <= 0) {
                due.add(t);
                it.remove();
            }
        }
        for (Task t : due) t.action.run();
    }

    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent event) {
        TASKS.clear();
    }

    /** Multi bow arrows ignore the target's invulnerability frames. */
    @SubscribeEvent
    public static void onImpact(ProjectileImpactEvent event) {
        if (!ExtraBows.MULTI_RESETS_IFRAMES) return;
        if (!(event.getProjectile() instanceof AbstractArrow arrow) || arrow.level().isClientSide) return;
        if (!arrow.getTags().contains(CustomBowItem.MULTI_TAG)) return;
        if (event.getRayTraceResult() instanceof EntityHitResult hit
                && hit.getEntity() instanceof LivingEntity target) {
            target.invulnerableTime = 0;
        }
    }
}
